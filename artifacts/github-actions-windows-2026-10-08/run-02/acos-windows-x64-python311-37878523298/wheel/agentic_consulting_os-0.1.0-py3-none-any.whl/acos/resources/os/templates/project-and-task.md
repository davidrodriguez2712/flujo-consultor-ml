# Plantillas de proyecto y tarea

Copiar solo lo que el trabajo requiera. Completar los campos conocidos, marcar lo pendiente y borrar instrucciones entre corchetes antes de compartir. No guardar credenciales en estos documentos.

## Brief de proyecto

Usar en intake cuando haga falta acordar encargo, decisión y límites. Para una tarea pequeña dentro de un proyecto activo, basta el contrato de tarea.

```markdown
# PROJECT — [nombre corto]

## Control
- ID:
- Cliente/equipo:
- Owner de negocio:
- Consultor responsable:
- Fecha / versión:
- Estado operativo:

## Contexto y necesidad
- Situación actual:
- Problema u oportunidad:
- Usuarios/áreas afectadas:
- Por qué ahora:

## Decisión que se debe habilitar
- Decisor:
- Decisión/acción:
- Fecha o cadencia en que se necesita:
- Qué cambiará según el resultado:

## Objetivo y aceptación
- Objetivo:
- Medida de éxito y definición:
- Criterios de aceptación:
- No-objetivos:

## Scope y restricciones
- Incluido:
- Excluido:
- Fecha objetivo / hitos:
- Presupuesto o recursos relevantes:
- Restricciones legales, privacidad, seguridad o política del cliente:
- Nivel de riesgo/revisión:

## Datos, fuentes y entorno
- Fuentes potenciales / owners:
- Datos disponibles confirmados:
- Datos o accesos pendientes:
- Entorno/repositorio autorizado:
- Retención/eliminación aplicable:

## Ruta inicial
- Rutas candidatas: [RESEARCH / ANALYSIS / EXPERIMENT / MODEL / BUILD / PRODUCT_UI / DELIVERY]
- Hipótesis o preguntas abiertas:
- Próximo gate y responsable:

## Artefactos y enlaces
- [enlace o ruta] — [qué controla]
```

## Contrato de tarea

Usar cuando se asigna una unidad de trabajo a una persona o agente, especialmente si hay ejecución, cambios o revisión delegada.

```markdown
# TASK — [ID: título]

- Proyecto:
- Owner / ejecutor / reviewer:
- Estado:
- Fecha límite o ventana:

## Objetivo y decisión
- Resultado que se necesita:
- Decisión que informa:

## Inputs y fuentes canónicas
- Artefactos/rutas/versiones:
- Datos y fecha de extracción:
- Incertidumbres conocidas:

## Alcance
- Incluye:
- Excluye:
- Write scope permitido:
- Herramientas/accesos autorizados:

## Restricciones y riesgos
- Privacidad/seguridad:
- Método/supuestos que no deben cambiarse sin aprobación:
- Condición de parada/escalamiento:

## Aceptación
- [ ] Criterio observable 1:
- [ ] Criterio observable 2:
- Evidencia que se adjuntará:

## Handoff
- Artefacto final/ruta:
- Limitaciones y trabajo no realizado:
- Siguiente owner/acción:
```

## Mapa de proyecto para seis engagements

Ejemplo organizativo; crear cada repo bajo el control de acceso correspondiente. El directorio padre agrupa localmente, pero no aísla datos ni constituye una barrera de seguridad. La estructura real se adapta a políticas, volumen, stack y artifacts necesarios.

```text
consulting-portfolio/                 # Agrupación local únicamente
├── aurora-card-activation/            # Repo/espacio aislado de Aurora
│   ├── PROJECT.md
│   ├── decisions/
│   ├── data/
│   ├── analysis/
│   └── delivery/
├── boreal-retention-prioritization/    # Repo/espacio aislado de Boreal
│   ├── PROJECT.md
│   ├── decisions/
│   ├── data/
│   ├── model/
│   ├── product-ui/                    # Solo por cola de trabajo para analistas
│   └── delivery/
├── cumbre-campaign-incrementality/     # Repo/espacio aislado de Cumbre
│   ├── PROJECT.md
│   ├── experiment/
│   └── delivery/
├── delta-data-quality/                 # Repo/espacio aislado de Delta
│   ├── PROJECT.md
│   ├── data-contracts/
│   ├── analysis/
│   └── delivery/
├── estrella-demand-forecast/           # Repo/espacio aislado de Estrella
│   ├── PROJECT.md
│   ├── data/
│   ├── model/
│   └── delivery/                       # Reporte; no UI por defecto
└── faro-market-research/               # Repo/espacio aislado de Faro
    ├── PROJECT.md
    ├── sources/
    ├── findings/
    └── delivery/
```

No crear todos los directorios vacíos en cada repo. Mantener datos, instrucciones y credenciales separados según los controles del cliente.
