# Plantillas de findings y QA

Aplicar al nivel de riesgo y tipo de entrega. No llenar cada campo si no aplica; la ausencia de una comprobación debe quedar clara cuando importe.

## Finding trazable

Usar para hallazgos que sostienen recomendación, priorización o decisión.

```markdown
### [F-##] [afirmación concisa]

- Tipo: [hecho descriptivo / diagnóstico / predicción / estimación causal / hipótesis]
- Relevancia para la decisión:
- Población, unidad y período:
- Evidencia: [tabla/figura/query/fuente + versión/ruta]
- Método/denominador/comparador:
- Incertidumbre o limitación:
- Alternativas/explicaciones pendientes:
- Confianza: [nivel y razón, no solo etiqueta]
- Próximo paso o decisión que informa:
```

## Checklist de revisión de entrega

Usar antes de compartir una recomendación, análisis o artifact con el cliente. Ajustar el rigor al riesgo; un reporte ejecutivo y un modelo operativo requieren evidencias distintas.

```markdown
# QA — [entregable/version]

- Reviewer / fecha:
- Audiencia y decisión:
- Nivel de riesgo:

## Contenido y evidencia
- [ ] Respuesta y recomendación coinciden con el encargo aprobado.
- [ ] Las afirmaciones materiales apuntan a evidencia reproducible o fuente verificable.
- [ ] Totales, denominadores, períodos, moneda/unidades y redondeos reconciliados.
- [ ] Asociación, predicción y causalidad se nombran correctamente.
- [ ] Limitaciones, supuestos y resultados negativos pertinentes están visibles.
- [ ] No se extrapola a población o período sin sustento.

## Uso y presentación
- [ ] Próxima acción, responsable, costo/riesgo y dependencias son claros cuando aplican.
- [ ] Lenguaje/gráficos adecuados a la audiencia; definiciones necesarias incluidas.
- [ ] Privacidad, anonimización y permiso de distribución verificados.
- [ ] Links/archivos abren desde el entorno esperado.

## Resultado
- Estado: [PASS / PASS con límites / REVISE / BLOCKED]
- Hallazgos y severidad:
- Correcciones/re-chequeos:
- Pendientes y owner:
- Aprobación humana requerida por:
```
