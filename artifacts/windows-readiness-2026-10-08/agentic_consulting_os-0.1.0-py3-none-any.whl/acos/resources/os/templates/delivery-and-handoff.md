# Plantillas de delivery y handoff

Usar cuando hace falta identificar lo que se comparte, cómo se reproduce o quién lo opera después. Para una consulta puntual sin artifact persistente, basta el registro de decisión aplicable.

## Manifest de delivery

```markdown
# Delivery manifest — [proyecto/paquete]

- Versión / fecha / preparado por:
- Destinatario y owner:
- Decisión/acción habilitada:
- Canal y permiso de distribución:

## Contenido
| Artifact | Ruta/link y versión | Propósito | Evidencia/fuente | Owner |
|---|---|---|---|---|
| | | | | |

## Reproducción y límites
- Cómo reproducir/actualizar:
- Datos, período y definiciones:
- Supuestos, exclusiones y limitaciones:
- Qué no incluye este paquete:
- Elementos no probados o pendientes:

## Operación (si aplica)
- Owner operativo:
- Cadencia / monitoreo / threshold:
- Acción ante error o drift:
- Revisión/override humano:
- Dependencias y costo recurrente:

## Cierre
- Aceptación por / fecha o estado pendiente:
- Decisiones registradas en:
- Accesos retirados/transferidos si aplica:
- Retención/eliminación acordada:
- Próxima acción, responsable y fecha:
```

## Nota de handoff de sesión

```markdown
# Handoff — [proyecto / fecha]

- Objetivo y etapa actual:
- Decisión pendiente:
- Estado y último gate alcanzado:
- Qué se completó (con links/versiones):
- Evidencia revisada:
- Supuestos, límites y dudas:
- Cambios realizados y archivos afectados:
- No hacer / restricciones:
- Próxima acción concreta:
- Owner entrante:
```

No incluir secretos ni trasladar información a otro proyecto. Ubicar este handoff en el espacio autorizado del proyecto.
